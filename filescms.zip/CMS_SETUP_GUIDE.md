# SmileNest CMS Setup Guide

## 📁 New Files Added
```
smilenest/
├── admin/
│   ├── index.html        ← CMS login panel
│   └── config.yml        ← CMS content structure
├── _data/
│   ├── settings.json     ← Clinic info (phone, address, hours)
│   ├── gallery.json      ← Photo gallery images
│   ├── reviews.json      ← Patient testimonials
│   └── doctors.json      ← Doctor profile
├── cms-loader.js         ← Loads JSON data into the page
├── netlify.toml          ← Netlify build config
└── (existing files unchanged)
```

---

## 🚀 One-Time Developer Setup (15 minutes)

### Step 1 — Push to GitHub
Make sure all files including the new ones are committed and pushed to your GitHub repo.

### Step 2 — Deploy on Netlify
1. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
2. Connect your GitHub repo
3. Build settings: leave blank (static site, no build command needed)
4. Click **Deploy site**

### Step 3 — Enable Netlify Identity
1. In Netlify dashboard → **Site settings** → **Identity**
2. Click **Enable Identity**
3. Under **Registration** → set to **Invite only** (so only your client can log in)
4. Scroll to **Git Gateway** → click **Enable Git Gateway**

### Step 4 — Invite the Client
1. In Netlify → **Identity** tab → **Invite users**
2. Enter the client's email
3. They'll receive an email to set their password

### Step 5 — Done! ✅
The CMS is live at: `https://your-site.netlify.app/admin`

---

## 🖥️ How the Client Uses the CMS

1. Go to `https://your-site.netlify.app/admin`
2. Log in with their email & password
3. They'll see a dashboard with these sections:

| Section | What they can do |
|---|---|
| **Photo Gallery** | Add/remove monthly photos with captions |
| **Patient Reviews** | Add new Google reviews |
| **Doctor Profile** | Update photo, bio, experience |
| **Clinic Info** | Update phone, address, hours |

4. To add a photo: Click **Photo Gallery** → **New Photo** → drag & drop image → **Publish**
5. Netlify auto-redeploys in ~30 seconds — site is live!

---

## 🔄 How It Works (Technical)
- CMS saves content as JSON files to your GitHub repo
- Netlify detects the commit and redeploys automatically
- `cms-loader.js` fetches the JSON files and renders them into the page
- No database, no backend — everything is Git-based

---

## ❓ Troubleshooting

**Client can't log in?**
→ Check Netlify Identity is enabled and Git Gateway is turned on

**Images not showing after upload?**
→ Images are saved to `/images/uploads/` folder in your repo. Make sure the folder exists.

**Changes not appearing on site?**
→ Wait ~60 seconds for Netlify to redeploy. Check the **Deploys** tab in Netlify dashboard.
